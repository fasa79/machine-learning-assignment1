Assignment 1 - Machine Learning

Author: Fadhluddin bin Sahlan	1817445

NOTICE:
To get the same results as portrayed in the report just straight away run the model.py file.
Running the preprocess.py file will create new Train_data.csv and Test_data.csv files which
will affect the performance of the model.